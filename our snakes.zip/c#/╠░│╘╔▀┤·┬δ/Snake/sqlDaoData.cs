﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Snake
{
    class sqlDaoData
    {
        string user;
        string pwd;
        string score;
        string grade;
        public string User { get => user; set => user = value; }
        public string Pwd { get => pwd; set => pwd = value; }
        public string Score { get => score; set => score = value; }
        public string Grade { get => grade; set => grade = value; }
    }
}
