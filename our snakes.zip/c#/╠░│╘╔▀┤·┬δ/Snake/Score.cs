﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Snake
{
    class Score
    {
        private string name;

        public string Name { get => name; set => name = value; }

        public string Score_Name(int score)
        {
            if (score == 100)
                return this.Name = "最强王者";
            else if (score <= 20)
              return this.Name = "倔强青铜";
            else if (score > 20 && score <= 40)
                return this.Name = "秩序白银";
            else if (score > 40 && score <= 60)
                return this.Name = "荣耀黄金";
            else if (score > 60 && score <= 80)
                return this.Name = "永恒钻石";
            else
                return this.Name = "至尊星耀";
        }
    }
}
