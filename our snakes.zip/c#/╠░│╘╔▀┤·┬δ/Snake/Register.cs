﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;

namespace Snake
{
    public partial class Register : Form
    {
        public Register()
        {
            InitializeComponent();
        }
        private void bt1_OH_Click(object sender, EventArgs e)
        {
            string user1 = textBox_name.Text.Trim();
            string pwd1 = textBox_pwd.Text.Trim();
            new sqlDaoImp().zhuCe(user1, pwd1);
        }
    }
}
