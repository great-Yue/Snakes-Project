﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Snake
{
    ///partial关键字是局部类型的意思，就是说有这个关键字的类、结构或接口可以写成几个部分
    public partial class Game_Begin : Form
    {
        public Game_Begin()
        {
            InitializeComponent();
        }
        /// <summary>
        /// 用来设置游戏难度
        /// </summary>
        public static int time_interval = 100;

        private void button1_Click(object sender, EventArgs e)
        {
            Snake snake = new Snake();
            snake.ShowDialog(); 
        }

        private void bt_chose_Click(object sender, EventArgs e)
        {
            Difficulty_selection difficulty_Selection = new Difficulty_selection();
            difficulty_Selection.Show();
            this.Hide();
        }

        private void bt_Help_Click(object sender, EventArgs e)
        {
            Help help = new Help();

            help.Show();
            this.Hide();
        }

        private void bt_exits_Click(object sender, EventArgs e)
        {
            System.Environment.Exit(0);
        }

        private void bt_History_Click(object sender, EventArgs e)
        {
            Show_Score show_Score = new Show_Score();
            show_Score.Show();
            this.Close();
        }
    }
}
