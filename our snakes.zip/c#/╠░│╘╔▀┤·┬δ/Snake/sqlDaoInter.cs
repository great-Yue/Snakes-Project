﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace Snake
{
    interface sqlDaoInter

    {
        //用户登录判断的接口
        void degLu(string user1, string pwd1);
        //用户注册判断的接口
        void zhuCe(string user1, string pwd1);
        //返回玩家ID
        String  getId();
        //返回玩家分数
        String getSorce();
        //返回玩家段位
        String getGrade();
    }
}
