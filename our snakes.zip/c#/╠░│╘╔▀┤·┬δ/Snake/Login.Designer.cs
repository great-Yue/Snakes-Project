﻿namespace Snake
{
    partial class Login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Login));
            this.label1 = new System.Windows.Forms.Label();
            this.lb_Name = new System.Windows.Forms.Label();
            this.lb_password = new System.Windows.Forms.Label();
            this.tB_Name = new System.Windows.Forms.TextBox();
            this.tB_password = new System.Windows.Forms.TextBox();
            this.bt1_ok = new System.Windows.Forms.Button();
            this.bt_Register = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("华文琥珀", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(232, 81);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(364, 44);
            this.label1.TabIndex = 0;
            this.label1.Text = "欢迎来到贪吃蛇！";
            // 
            // lb_Name
            // 
            this.lb_Name.AutoSize = true;
            this.lb_Name.BackColor = System.Drawing.Color.Transparent;
            this.lb_Name.Font = new System.Drawing.Font("宋体", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lb_Name.Location = new System.Drawing.Point(178, 180);
            this.lb_Name.Name = "lb_Name";
            this.lb_Name.Size = new System.Drawing.Size(110, 24);
            this.lb_Name.TabIndex = 1;
            this.lb_Name.Text = "用户名：";
            // 
            // lb_password
            // 
            this.lb_password.AutoSize = true;
            this.lb_password.BackColor = System.Drawing.Color.Transparent;
            this.lb_password.Font = new System.Drawing.Font("宋体", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lb_password.Location = new System.Drawing.Point(178, 247);
            this.lb_password.Name = "lb_password";
            this.lb_password.Size = new System.Drawing.Size(98, 24);
            this.lb_password.TabIndex = 2;
            this.lb_password.Text = "密 码：";
            // 
            // tB_Name
            // 
            this.tB_Name.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.tB_Name.Font = new System.Drawing.Font("宋体", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tB_Name.Location = new System.Drawing.Point(319, 174);
            this.tB_Name.Multiline = true;
            this.tB_Name.Name = "tB_Name";
            this.tB_Name.Size = new System.Drawing.Size(210, 39);
            this.tB_Name.TabIndex = 3;
            // 
            // tB_password
            // 
            this.tB_password.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.tB_password.Font = new System.Drawing.Font("宋体", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tB_password.Location = new System.Drawing.Point(319, 239);
            this.tB_password.Multiline = true;
            this.tB_password.Name = "tB_password";
            this.tB_password.Size = new System.Drawing.Size(210, 38);
            this.tB_password.TabIndex = 4;
            // 
            // bt1_ok
            // 
            this.bt1_ok.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.bt1_ok.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.bt1_ok.Font = new System.Drawing.Font("宋体", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.bt1_ok.Location = new System.Drawing.Point(216, 331);
            this.bt1_ok.Name = "bt1_ok";
            this.bt1_ok.Size = new System.Drawing.Size(126, 42);
            this.bt1_ok.TabIndex = 5;
            this.bt1_ok.Text = "登  录";
            this.bt1_ok.UseVisualStyleBackColor = false;
            this.bt1_ok.Click += new System.EventHandler(this.button1_Click);
            // 
            // bt_Register
            // 
            this.bt_Register.Font = new System.Drawing.Font("宋体", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.bt_Register.Location = new System.Drawing.Point(437, 331);
            this.bt_Register.Name = "bt_Register";
            this.bt_Register.Size = new System.Drawing.Size(126, 42);
            this.bt_Register.TabIndex = 6;
            this.bt_Register.Text = "注  册";
            this.bt_Register.UseVisualStyleBackColor = true;
            this.bt_Register.Click += new System.EventHandler(this.bt_Register_Click);
            // 
            // Login
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(777, 458);
            this.Controls.Add(this.bt_Register);
            this.Controls.Add(this.bt1_ok);
            this.Controls.Add(this.tB_password);
            this.Controls.Add(this.tB_Name);
            this.Controls.Add(this.lb_password);
            this.Controls.Add(this.lb_Name);
            this.Controls.Add(this.label1);
            this.Name = "Login";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "登录/注册";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lb_Name;
        private System.Windows.Forms.Label lb_password;
        private System.Windows.Forms.TextBox tB_Name;
        private System.Windows.Forms.TextBox tB_password;
        private System.Windows.Forms.Button bt1_ok;
        private System.Windows.Forms.Button bt_Register;
    }
}