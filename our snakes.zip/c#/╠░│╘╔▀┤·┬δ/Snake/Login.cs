﻿using System;
using System.Windows.Forms;

namespace Snake
{
    public partial class Login : Form
    {
        public static string LoginUser { get; set; }
        public Login()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            String user1 = tB_Name.Text.Trim();
            String pwd1 = tB_password.Text.Trim();
            new sqlDaoImp().degLu(user1, pwd1);
        }
        private void bt_Register_Click(object sender, EventArgs e)
        {
            Register register = new Register();
            register.ShowDialog();
            this.Hide();
        }
    }
}
