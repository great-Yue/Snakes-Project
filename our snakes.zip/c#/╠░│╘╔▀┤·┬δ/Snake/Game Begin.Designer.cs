﻿namespace Snake
{
    partial class Game_Begin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Game_Begin));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.bt_exits = new System.Windows.Forms.Button();
            this.bt_Help = new System.Windows.Forms.Button();
            this.bt_History = new System.Windows.Forms.Button();
            this.bt_chose = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.groupBox1.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.groupBox1.Controls.Add(this.bt_exits);
            this.groupBox1.Controls.Add(this.bt_Help);
            this.groupBox1.Controls.Add(this.bt_History);
            this.groupBox1.Controls.Add(this.bt_chose);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Location = new System.Drawing.Point(115, 5);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox1.Size = new System.Drawing.Size(400, 568);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            // 
            // bt_exits
            // 
            this.bt_exits.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.bt_exits.Font = new System.Drawing.Font("幼圆", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.bt_exits.Location = new System.Drawing.Point(115, 411);
            this.bt_exits.Margin = new System.Windows.Forms.Padding(4);
            this.bt_exits.Name = "bt_exits";
            this.bt_exits.Size = new System.Drawing.Size(143, 38);
            this.bt_exits.TabIndex = 5;
            this.bt_exits.Text = "退出游戏";
            this.bt_exits.UseVisualStyleBackColor = false;
            this.bt_exits.Click += new System.EventHandler(this.bt_exits_Click);
            // 
            // bt_Help
            // 
            this.bt_Help.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.bt_Help.Font = new System.Drawing.Font("幼圆", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.bt_Help.Location = new System.Drawing.Point(115, 338);
            this.bt_Help.Margin = new System.Windows.Forms.Padding(4);
            this.bt_Help.Name = "bt_Help";
            this.bt_Help.Size = new System.Drawing.Size(143, 38);
            this.bt_Help.TabIndex = 4;
            this.bt_Help.Text = "游戏帮助";
            this.bt_Help.UseVisualStyleBackColor = false;
            this.bt_Help.Click += new System.EventHandler(this.bt_Help_Click);
            // 
            // bt_History
            // 
            this.bt_History.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.bt_History.Font = new System.Drawing.Font("幼圆", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.bt_History.Location = new System.Drawing.Point(115, 266);
            this.bt_History.Margin = new System.Windows.Forms.Padding(4);
            this.bt_History.Name = "bt_History";
            this.bt_History.Size = new System.Drawing.Size(143, 38);
            this.bt_History.TabIndex = 3;
            this.bt_History.Text = "历史新高";
            this.bt_History.UseVisualStyleBackColor = false;
            this.bt_History.Click += new System.EventHandler(this.bt_History_Click);
            // 
            // bt_chose
            // 
            this.bt_chose.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.bt_chose.Font = new System.Drawing.Font("幼圆", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.bt_chose.Location = new System.Drawing.Point(115, 198);
            this.bt_chose.Margin = new System.Windows.Forms.Padding(4);
            this.bt_chose.Name = "bt_chose";
            this.bt_chose.Size = new System.Drawing.Size(143, 38);
            this.bt_chose.TabIndex = 2;
            this.bt_chose.Text = "游戏难度";
            this.bt_chose.UseVisualStyleBackColor = false;
            this.bt_chose.Click += new System.EventHandler(this.bt_chose_Click);
            // 
            // label1
            // 
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label1.Font = new System.Drawing.Font("幼圆", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(115, 46);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(143, 49);
            this.label1.TabIndex = 1;
            this.label1.Text = "贪吃蛇";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button1.Font = new System.Drawing.Font("幼圆", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button1.Location = new System.Drawing.Point(115, 126);
            this.button1.Margin = new System.Windows.Forms.Padding(4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(143, 38);
            this.button1.TabIndex = 0;
            this.button1.Text = "开始游戏";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Game_Begin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.ClientSize = new System.Drawing.Size(645, 576);
            this.Controls.Add(this.groupBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Game_Begin";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "游戏开始";
            this.groupBox1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button bt_chose;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button bt_exits;
        private System.Windows.Forms.Button bt_Help;
        private System.Windows.Forms.Button bt_History;
    }
}