﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Snake
{
    class sqlDaoImp : sqlDaoInter
    {
        //用户登录判断的接口实现
        public void degLu(String user1, string pwd1)
        {
            //
            sqlDaoData data = new sqlDaoData();
            data.User = user1;
            data.Pwd = pwd1;
            //
            SqlConnection sqlconn = new sqlUtil().sqlConn_1();
            //
            sqlconn.Open();
            //
            string strSql = "select * from user1 where username='" + data.User + "'";
            //
            SqlCommand comm = new SqlCommand(strSql, sqlconn);
            SqlDataReader sqlread = comm.ExecuteReader();
            if (sqlread.Read())
            {
                if (sqlread["password"].ToString().Trim().Equals(data.Pwd))
                {
                    new Game_Begin().Show();
                    Login.LoginUser = user1;
                    new Login().Close();
                }
                else
                {
                    MessageBox.Show("密码错误");
                }
            }
            else
            {
                MessageBox.Show("该用户名不存在");
            }
        }
        //获取段位
        public string getGrade()
        {
            string grade = null;
            sqlDaoData data = new sqlDaoData();
            SqlConnection sqlconn = new sqlUtil().sqlConn_1();

            sqlconn.Open();

            string strSql = "select grade from user1 where username='" + Login.LoginUser + "' ";
            SqlCommand comm = new SqlCommand(strSql, sqlconn);
            SqlDataReader sqlread = comm.ExecuteReader();
            if (sqlread.Read())
            {
                grade = sqlread["grade"].ToString();
            }
            return grade;

        }
        //获取用户名并返回
        public String getId()
        {
            string name = null; 
            SqlConnection sqlconn = new sqlUtil().sqlConn_1();
            sqlconn.Open();
            string strSql = "select * from user1 where username='" +Login.LoginUser+ "'";
            SqlCommand comm = new SqlCommand(strSql, sqlconn);
            SqlDataReader sqlread = comm.ExecuteReader();
            if (sqlread.Read()) {
                name= sqlread["username"].ToString();
            }
            return name;
        }
        //获取分数
        public string getSorce()
        {
           
            SqlConnection sqlconn = new sqlUtil().sqlConn_1();
            sqlconn.Open();
            string score= null;
            string strSql = "select * from user1 where username='" + Login.LoginUser + "'";
            SqlCommand comm = new SqlCommand(strSql, sqlconn);
            SqlDataReader sqlread = comm.ExecuteReader();
            if (sqlread.Read()) {
                score =  sqlread["score"].ToString();
            }
                return score ;
        }
        //用户注册判断的接口实现
        public void zhuCe(string user1, string pwd1)
        {
            sqlDaoData data = new sqlDaoData();
            data.User= user1;
            data.Pwd = pwd1;
            SqlConnection sqlconn = new sqlUtil().sqlConn_1();
            sqlconn.Open();
            string strSql = "insert into user1 (username,password) values ('" +data.User + "','" + data.Pwd + "')";
            try
            {
                SqlCommand comm = new SqlCommand(strSql, sqlconn);
                int row = comm.ExecuteNonQuery();

                if (row > 0)
                {
                    MessageBox.Show("注册成功");
                    new Login().ShowDialog();
                    new Register().Close();
                }
            }
            catch
            {
                MessageBox.Show("用户名已存在");
            }
        }
        //提交最高分记录与段位
        public void insterSorce(int score1,string grade) {

            SqlConnection sqlconn = new sqlUtil().sqlConn_1();

            sqlconn.Open();

            string strSql = "update user1 set score='" + score1 + "',grade='"+grade+"' where username='"+Login.LoginUser+ "'and score<"+score1+"  ";
            SqlCommand comm = new SqlCommand(strSql, sqlconn);
            SqlDataReader sqlread = comm.ExecuteReader();

            

        } 
    }
}
