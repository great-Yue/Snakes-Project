﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Snake
{
    public partial class Show_Score : Form
    {
        public Show_Score()
        {
            InitializeComponent();
            sqlDaoImp sqlDao = new sqlDaoImp();
            lb_username.Text = Login.LoginUser;
            lb_Score.Text = sqlDao.getSorce();
            lb_location.Text = sqlDao.getGrade();
        }

        private void bt2_OK_Click(object sender, EventArgs e)
        {
            Game_Begin game_Begin = new Game_Begin();
            game_Begin.ShowDialog();
            this.Close();
        }

    }
}
