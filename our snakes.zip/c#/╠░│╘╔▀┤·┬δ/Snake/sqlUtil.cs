﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace Snake
{
    class sqlUtil
    {

        public SqlConnection sqlConn_1()
        {
            SqlConnectionStringBuilder sqlBuilder = new SqlConnectionStringBuilder();
            sqlBuilder.DataSource = "DESKTOP-REE34NK\\MSSQLSERVER02";
            sqlBuilder.UserID = "sa";
            sqlBuilder.Password = "123";
            sqlBuilder.InitialCatalog = "mydata";
            SqlConnection sqlconn = new SqlConnection(sqlBuilder.ToString());
            return sqlconn;
           
        }
    }
}
//连接数据库：
//1、连接到数据源——>即存储数据库所在的IP地址（本机地址）
//2、登录名、密码
//3、连接的数据库名称