﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Snake
{
    class Map
    {
        public void Paint_Map(Panel panel)
        {
            int col = 38;
            int row = 50;
            int drawRow = 0;
            int drawCol = 0;
            Pen black = new Pen(Color.Gray, 1);
            //black.DashStyle = System.Drawing.Drawing2D.DashStyle.DashDot;
            Graphics g = panel.CreateGraphics();
            //画垂直线
            for (int i = 0; i <= row; i++)
            {
                g.DrawLine(black, 0, drawCol, 380, drawCol);
                drawCol += 10;
            }
            // 画水平线
            for (int j = 0; j <= col; j++)
            {
                g.DrawLine(black, drawRow, 0, drawRow, 500);
                drawRow += 10;
            }
        }
    }
}
